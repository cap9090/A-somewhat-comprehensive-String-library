/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pathfinders;

import graph.Graph;

public class Dijkstra implements PathFinder{

    //all these instance variables should be declared within
    //the method, but I was lazy here.
    
    public int [] d;
    public int [] p;
    public static final int INFINITY = 100000;
    public int [] heap;
    public int heapIndex;
    
    
    
    private void heapsort(){
        for (int start = heapIndex; start < heap.length; start++){
            int child = start;
            int parent = (child -1 + heapIndex)/ 2; //have to include this offset in numerator because we change the start index of the sort everytime
            while(parent >= heapIndex && d[heap[parent] -1] > d[heap[child] -1]){
                swap(parent, child);
                child = parent;
                parent = (child -1 + heapIndex)/2 ; 
            } 
        }
    }
    
    private void swap(int parentIndex, int childIndex){
        int temp = heap[parentIndex];
        heap[parentIndex] = heap [childIndex];
        heap[childIndex] = temp;
    }
    
    public int[] findPath(Graph g) {
       

        //---------------------BELOW IS A HEAP IMPLEMENTATION WITH AN ARRAY--------------
        // i would guess 50 percent of it is print statements, I need to learn to use a debugger
       
       int numNodes = g.getNumberOfNodes();
        
        d = new int[numNodes -1];
        p = new int[numNodes -1];
        heap = new int[numNodes -1];
        heapIndex = 0;

        for (int i = 0 ; i < d.length; i ++){
            p[i] = 0;
            d[i] = INFINITY;
            heap[i] = i + 1;
        }
        
        
        int [][] adjacent = g.getNeighborsOfNode(0);
        
        for (int i = 0; i < adjacent.length; i ++){
            d[adjacent[i][0] - 1] = adjacent[i][1]; 
        }
        
        for (int i = 0; i < heap.length; i ++){
            System.out.print(" " + heap[i]);
        }
        System.out.println();
        
        heapsort();
        
        for (int i = 0; i < heap.length; i ++){
            System.out.print(" " + heap[i]);
        }
        System.out.println();
        
        while(heapIndex != heap.length -1){
  
            int in = heap[heapIndex++];
            System.out.println("currently the heap index is " + heapIndex);
                    
            System.out.println("our current vertex were visiting is " + in);
             
            int [][] temp = g.getNeighborsOfNode(in);                
            System.out.println(" the neighbor array now is ");
                  
            System.out.println(" and its length is " + temp.length);
            for (int i = 0; i < temp.length; i++){
                System.out.println("" + temp[i][0] + " " + temp[i][1]);
                if (d[in - 1] + temp[i][1] < d[temp[i][0] - 1]){
                    d[temp[i][0] - 1 ] = d [in - 1] + temp[i][1];
                    p[temp[i][0]  -1 ] = in;
                }
            }
           
            heapsort();
            
            System.out.println();
            System.out.println("our heap now is ");
            for (int i = 0; i < heap.length; i++){
                System.out.print(" " + heap[i]);
            }
            System.out.println();
            System.out.println(" the array p is ");
            for (int i = 0; i < p.length; i ++){
                System.out.print(" " + p[i]);
            }
            System.out.println();
        }
        
        /* while loop is done all this junk code after
           is just getting the path from 0 to 1 into an
            array, i realized after I did this, I should 
            have just put all the proper vertices into a 
            stack and just popped them off to reverse them
            but oh well
            */
        
        
        System.out.println(" the array p is ");
        for (int i = 0; i < p.length; i ++){
            System.out.print(" " + p[i]);
        }
        
        System.out.println();
        int index = 0; 
        int count = 0;
        int [] tempArray = new int[p.length];
        for (int i = 1 ; i < p.length && p[index] != 0; i++, count++){
            tempArray[i] = p[index];
            index = p[index] - 1;
        }
       
        int[] finalArray  = new int[count + 2];
        finalArray[0] = 0;        
        finalArray[finalArray.length -1 ] = 1;

        for (int i = 1; i <= count ; i ++){
            finalArray[i] = tempArray[count -i + 1];
        }
        System.out.println("the final array is ");
        for (int i = 0; i < finalArray.length; i ++){
            System.out.print(" " + finalArray[i]);
        }
        System.out.println();
        
        if(finalArray[1] == 1)
        {
            System.out.println("DISCONNECTED GRAPH! NO PATH");
        }
        
        return (finalArray);
    }

}
        

        
    
  
