package pathfinders;
import graph.Graph;

public interface PathFinder {
    public int[] findPath(Graph g);
}
